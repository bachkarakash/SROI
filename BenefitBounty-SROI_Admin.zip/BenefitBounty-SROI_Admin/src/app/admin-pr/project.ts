export interface IProject {
    id: number;
    name: string;
    code: string;
    engageArea: string;
    summary: string;
    duration: string;
    budget: string;
    company: string;
    location: string;
    emailofPOC: string;
  }
  