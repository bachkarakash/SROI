import { ContactPersons } from './contact-persons';

describe('ContactPersons', () => {
  it('should create an instance', () => {
    expect(new ContactPersons()).toBeTruthy();
  });
});
