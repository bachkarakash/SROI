export class ContactPersons
{Name:string;
Phone:number;
Email:string;
}
