package benefitBountyService.models.sroi;

public class Step {

    private String stepId;
//    private

    public String getStepId() {
        return stepId;
    }

    public void setStepId(String stepId) {
        this.stepId = stepId;
    }
}
