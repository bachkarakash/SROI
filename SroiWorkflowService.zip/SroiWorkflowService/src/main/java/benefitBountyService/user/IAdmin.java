package benefitBountyService.user;

public interface IAdmin extends IUser {

}
