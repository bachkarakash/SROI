package benefitBountyService.user;

public interface IUser {

}
